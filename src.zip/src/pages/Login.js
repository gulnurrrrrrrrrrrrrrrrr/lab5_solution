// src/pages/Login.js
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

const Login = () => {
  const { login } = useAuth();
  const [email, setEmail] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleLogin = () => {
    const user = login(email);
    if (user) {
      navigate("/dashboard");
    } else {
      setError("Неверный email или пользователь не авторизован");
    }
  };

  return (
    <div className="page-wrapper" style={{ padding: "2rem" }}>
      <h2>Вход</h2>
      <input
        type="email"
        placeholder="Введите email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        style={{ padding: "0.5rem", width: "250px" }}
      />
      <br /><br />
      <button onClick={handleLogin} style={{ padding: "0.5rem 1rem" }}>Войти</button>
      {error && <p style={{ color: "red" }}>{error}</p>}
    </div>
  );
};

export default Login;