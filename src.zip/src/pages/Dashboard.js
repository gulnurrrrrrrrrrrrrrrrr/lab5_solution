import React, { useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import { fetchProjects } from "../redux/projectsSlice";
import { Link } from "react-router-dom";
import { useLanguage } from "../context/LanguageContext";

const Dashboard = () => {
  const dispatch = useDispatch();
  const { projects, loading, error } = useSelector((state) => state.projects);
  const { t } = useLanguage();

  useEffect(() => {
    dispatch(fetchProjects());
  }, [dispatch]);

  return (
    <div className="page-wrapper">
      <h2>{t.dashboard}</h2>

      {loading && <p>Загрузка проектов...</p>}
      {error && <p style={{ color: "red" }}>{error}</p>}

      <ul>
        {projects.map((project) => (
          <li key={project.id}>
            <Link to={`/project/${project.id}`}>{project.name}</Link> — {project.status}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Dashboard;
