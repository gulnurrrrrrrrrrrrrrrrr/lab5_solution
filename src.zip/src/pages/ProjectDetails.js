import React, { useEffect, useMemo, useState } from "react";
import { useParams } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import { fetchProjects } from "../redux/projectsSlice";
import { fetchTasks } from "../redux/tasksSlice";
import { DragDropContext, Droppable, Draggable } from "react-beautiful-dnd";
import { useTaskFormReducer } from "../hooks/useTaskFormReducer";
import { useLanguage } from "../context/LanguageContext";

const statuses = ["Planned", "In Progress", "Active", "Completed", "Ongoing"];

const ProjectDetails = () => {
  const { id } = useParams();
  const dispatch = useDispatch();
  const { t } = useLanguage();

  const { projects } = useSelector((state) => state.projects);
  const { tasks } = useSelector((state) => state.tasks);

  const [localTasks, setLocalTasks] = useState([]);
  const [formState, dispatchForm] = useTaskFormReducer();

  useEffect(() => {
    dispatch(fetchProjects());
    dispatch(fetchTasks());
  }, [dispatch]);

  useEffect(() => {
    setLocalTasks(tasks.filter((t) => t.projectId === Number(id)));
  }, [tasks, id]);

  const project = projects.find((p) => p.id === Number(id));

  const tasksByStatus = useMemo(() => {
    const grouped = {};
    statuses.forEach((status) => {
      grouped[status] = localTasks.filter((t) => t.status === status);
    });
    return grouped;
  }, [localTasks]);

  const onDragEnd = (result) => {
    const { source, destination } = result;
    if (!destination) return;

    const sourceStatus = source.droppableId;
    const destStatus = destination.droppableId;

    if (sourceStatus === destStatus) return;

    const updatedTasks = localTasks.map((task) => {
      if (task.id === Number(result.draggableId)) {
        return { ...task, status: destStatus };
      }
      return task;
    });

    setLocalTasks(updatedTasks);
  };

  const addTask = () => {
    if (formState.title.trim() === "") return;

    const newTask = {
      id: Date.now(),
      projectId: Number(id),
      title: formState.title,
      status: formState.status,
    };

    setLocalTasks((prev) => [...prev, newTask]);
    dispatchForm({ type: "RESET" });
  };

  if (!project) return <p>{t.notFound}</p>;

  return (
    <div className="page-wrapper">
      <h2>{project.name}</h2>
      <p>{project.description}</p>

      <div style={{ marginBottom: "2rem" }}>
        <h3>{t.createTask}</h3>
        <input
          type="text"
          placeholder={t.taskName}
          value={formState.title}
          onChange={(e) =>
            dispatchForm({ type: "SET_TITLE", payload: e.target.value })
          }
          style={{ padding: "0.5rem", width: "250px", marginRight: "1rem" }}
        />
        <select
          value={formState.status}
          onChange={(e) =>
            dispatchForm({ type: "SET_STATUS", payload: e.target.value })
          }
          style={{ padding: "0.5rem", marginRight: "1rem" }}
        >
          {statuses.map((s) => (
            <option key={s} value={s}>
              {s}
            </option>
          ))}
        </select>
        <button onClick={addTask} style={{ padding: "0.5rem 1rem" }}>
          {t.add}
        </button>
      </div>

      <DragDropContext onDragEnd={onDragEnd}>
        <div style={{ display: "flex", gap: "1rem", overflowX: "auto" }}>
          {statuses.map((status) => (
            <Droppable droppableId={status} key={status}>
              {(provided) => (
                <div
                  ref={provided.innerRef}
                  {...provided.droppableProps}
                  className="kanban-column"
                >
                  <h4>{status}</h4>
                  {tasksByStatus[status].map((task, index) => (
                    <Draggable
                      draggableId={task.id.toString()}
                      index={index}
                      key={task.id}
                    >
                      {(provided) => (
                        <div
                          ref={provided.innerRef}
                          {...provided.draggableProps}
                          {...provided.dragHandleProps}
                          className="task-card"
                          style={provided.draggableProps.style}
                        >
                          {task.title}
                        </div>
                      )}
                    </Draggable>
                  ))}
                  {provided.placeholder}
                </div>
              )}
            </Droppable>
          ))}
        </div>
      </DragDropContext>
    </div>
  );
};

export default ProjectDetails;
