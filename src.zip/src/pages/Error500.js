import React from "react";
import { Link } from "react-router-dom";

const Error500 = () => {
  return (
    <div className="page-wrapper" style={styles.container}>
      <h1>500</h1>
      <p>Внутренняя ошибка сервера</p>
      <Link to="/dashboard">На главную</Link>
    </div>
  );
};

const styles = {
  container: {
    textAlign: "center",
    padding: "4rem",
  },
};

export default Error500;