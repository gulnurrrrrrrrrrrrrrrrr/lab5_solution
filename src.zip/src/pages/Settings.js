import React from "react";
import { useTheme } from "../context/ThemeContext";
import { useLanguage } from "../context/LanguageContext";

const Settings = () => {
  const { theme, toggleTheme } = useTheme();
  const { language, toggleLanguage, t } = useLanguage();

  return (
    <div className="page-wrapper" style={{ padding: "2rem" }}>
      <h2>{t.settings}</h2>

      <div style={{ marginBottom: "1rem" }}>
        <strong>Тема:</strong> {theme}
        <br />
        <button
          onClick={toggleTheme}
          style={{
            marginTop: "0.5rem",
            padding: "0.5rem",
            borderRadius: "4px",
            backgroundColor: "#ddd",
            cursor: "pointer",
          }}
        >
          Переключить тему
        </button>
      </div>

      <div>
        <strong>Язык:</strong> {language}
        <br />
        <button
          onClick={toggleLanguage}
          style={{
            marginTop: "0.5rem",
            padding: "0.5rem",
            borderRadius: "4px",
            backgroundColor: "#ddd",
            cursor: "pointer",
          }}
        >
          Переключить язык
        </button>
      </div>
    </div>
  );
};

export default Settings;
