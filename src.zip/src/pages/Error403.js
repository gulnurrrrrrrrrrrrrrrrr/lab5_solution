import React from "react";
import { Link } from "react-router-dom";

const Error403 = () => {
  return (
    <div className="page-wrapper" style={styles.container}>
      <h1>403</h1>
      <p>Доступ запрещён</p>
      <Link to="/dashboard">Вернуться</Link>
    </div>
  );
};

const styles = {
  container: {
    textAlign: "center",
    padding: "4rem",
  },
};

export default Error403;