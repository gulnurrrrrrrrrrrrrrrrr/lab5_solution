// src/context/AuthContext.js
import React, { createContext, useState, useContext } from "react";
import users from "../data/users.json";

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [currentUser, setCurrentUser] = useState(null);

  const login = (email) => {
    const user = users.find(u => u.email === email && u.authenticated);
    if (user) setCurrentUser(user);
    return user;
  };

  const logout = () => setCurrentUser(null);

  return (
    <AuthContext.Provider value={{ currentUser, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);