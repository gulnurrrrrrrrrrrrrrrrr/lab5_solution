// src/context/LanguageContext.js
import React, { createContext, useState, useContext } from "react";

const LanguageContext = createContext();

const translations = {
  en: {
    login: "Login",
    dashboard: "Dashboard",
    settings: "Settings",
    logout: "Logout",
    createTask: "Create Task",
    taskName: "Task name",
    selectStatus: "Select status",
    add: "Add",
    notFound: "Page not found",
    forbidden: "Access denied",
    error: "Internal error",
    back: "Back to dashboard",
  },
  ru: {
    login: "Вход",
    dashboard: "Панель",
    settings: "Настройки",
    logout: "Выход",
    createTask: "Создать задачу",
    taskName: "Название задачи",
    selectStatus: "Выберите статус",
    add: "Добавить",
    notFound: "Страница не найдена",
    forbidden: "Доступ запрещён",
    error: "Внутренняя ошибка",
    back: "Назад на панель",
  },
};

export const LanguageProvider = ({ children }) => {
  const [language, setLanguage] = useState("ru");

  const toggleLanguage = () => {
    setLanguage((prev) => (prev === "en" ? "ru" : "en"));
  };

  const t = translations[language];

  return (
    <LanguageContext.Provider value={{ language, toggleLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => useContext(LanguageContext);
