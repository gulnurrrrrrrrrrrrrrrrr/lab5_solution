// src/hooks/useTaskFormReducer.js
import { useReducer } from "react";

const initialState = {
  title: "",
  status: "Planned",
};

function reducer(state, action) {
  switch (action.type) {
    case "SET_TITLE":
      return { ...state, title: action.payload };
    case "SET_STATUS":
      return { ...state, status: action.payload };
    case "RESET":
      return initialState;
    default:
      return state;
  }
}

export const useTaskFormReducer = () => {
  return useReducer(reducer, initialState);
};