// src/redux/tasksSlice.js
import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import data from "../data/tasks.json";

export const fetchTasks = createAsyncThunk("tasks/fetchTasks", async () => {
  return new Promise((resolve) => {
    setTimeout(() => resolve(data), 500); // имитация запроса
  });
});

const tasksSlice = createSlice({
  name: "tasks",
  initialState: {
    tasks: [],
    loading: false,
    error: null,
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchTasks.pending, (state) => {
        state.loading = true;
      })
      .addCase(fetchTasks.fulfilled, (state, action) => {
        state.tasks = action.payload;
        state.loading = false;
      })
      .addCase(fetchTasks.rejected, (state) => {
        state.loading = false;
        state.error = "Не удалось загрузить задачи";
      });
  },
});

export default tasksSlice.reducer;