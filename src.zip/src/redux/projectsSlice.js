// src/redux/projectsSlice.js
import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import data from "../data/projects.json";

export const fetchProjects = createAsyncThunk("projects/fetchProjects", async () => {
  return new Promise((resolve) => {
    setTimeout(() => resolve(data), 500); // имитация запроса
  });
});

const projectsSlice = createSlice({
  name: "projects",
  initialState: {
    projects: [],
    loading: false,
    error: null,
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchProjects.pending, (state) => {
        state.loading = true;
      })
      .addCase(fetchProjects.fulfilled, (state, action) => {
        state.projects = action.payload;
        state.loading = false;
      })
      .addCase(fetchProjects.rejected, (state) => {
        state.loading = false;
        state.error = "Не удалось загрузить проекты";
      });
  },
});

export default projectsSlice.reducer;