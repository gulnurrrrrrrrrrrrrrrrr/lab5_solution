import React from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { useLanguage } from "../context/LanguageContext";

const Header = () => {
  const { currentUser, logout } = useAuth();
  const { t } = useLanguage();

  return (
    <header
      style={{
        backgroundColor: "#333",
        color: "#fff",
        padding: "1rem",
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
      }}
    >
      <div>
        <Link
          to="/dashboard"
          style={{ color: "#fff", textDecoration: "none", fontWeight: "bold" }}
        >
          TaskFlow
        </Link>
      </div>
      <div>
        {currentUser ? (
          <>
            <span style={{ marginRight: "1rem" }}>{currentUser.name}</span>
            <Link
              to="/settings"
              style={{ color: "#fff", marginRight: "1rem" }}
            >
              {t.settings}
            </Link>
            <button
              onClick={logout}
              style={{
                padding: "0.3rem 0.6rem",
                cursor: "pointer",
                backgroundColor: "#555",
                color: "#fff",
                border: "none",
                borderRadius: "4px",
              }}
            >
              {t.logout}
            </button>
          </>
        ) : (
          <Link to="/" style={{ color: "#fff" }}>
            {t.login}
          </Link>
        )}
      </div>
    </header>
  );
};

export default Header;
